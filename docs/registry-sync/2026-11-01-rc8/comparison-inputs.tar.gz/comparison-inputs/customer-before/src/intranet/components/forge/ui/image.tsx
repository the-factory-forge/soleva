import { cn } from "#/intranet/forge/utils.ts";

export interface ImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  unoptimized?: boolean;
  /** Fill the parent (absolute inset-0) — next/image compatible. */
  fill?: boolean;
  /** Load eagerly with high fetch priority — next/image compatible. */
  priority?: boolean;
  sizes?: string;
  quality?: number;
}

/**
 * Plain <img> based Image. Sites that need an image optimizer replace
 * this file with a framework component — the props above keep the
 * component contract stable.
 */
export function Image({
  src,
  alt,
  width,
  height,
  unoptimized,
  fill,
  priority,
  sizes,
  quality,
  loading,
  className,
  ...props
}: ImageProps) {
  return (
    // oxlint-disable-next-line nextjs/no-img-element -- framework-agnostic shim
    <img
      src={src}
      alt={alt}
      width={fill ? undefined : width}
      height={fill ? undefined : height}
      sizes={sizes}
      loading={loading ?? (priority ? "eager" : "lazy")}
      fetchPriority={priority ? "high" : undefined}
      data-quality={quality}
      data-unoptimized={unoptimized || undefined}
      className={cn(fill && "absolute inset-0 h-full w-full", className)}
      {...props}
    />
  );
}
