export { cn } from "cnfast";
