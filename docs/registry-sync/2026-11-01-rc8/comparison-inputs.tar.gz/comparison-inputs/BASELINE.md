# Comparison boundary

Historical installed Registry source is mixed. No pristine historical installer output or exact historical dependency resolution was available. The old revision notes are provenance, not a proven reconstructed base. This is a bounded manual reconciliation, not a clean three-way merge claim.

`customer-before/` is the exact working source after Template verification and before Registry adoption. `incoming-installed/` is actual shadcn output with the SHA-pinned RC8 namespace and its resolved dependencies. `item-mapping.json` separates provider source, installed target and actual host destinations; ui-shims have public and intranet copies. Additional host wrapper inputs are preserved for caller review. The `database` item was installed for comparison, but only its existing migration-history helper is adopted: the host owns its DB initialization. Shared utility dependencies do not imply optional business/Agents plugins are installed.

`template-comparison/` preserves RC2 baseline, RC6 incoming, root-prepared merge candidates, the customer's pre-Template state and original migration metadata. Candidates required reviewed custom merges and are not a second final implementation. Every original migration SQL file remained byte-identical; only snapshot metadata was upgraded by the installed CLI. No customer database was read or changed.

`checks/` contains separate Template and final checks using only an owned disposable local database, fake email/OAuth transport and synthetic settings. Paths in the original command identify this isolated run; reproduce with the same package/CLI versions and an independent consumer. No secret env files are included.
