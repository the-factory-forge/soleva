#!/bin/sh
set -e

# Run Drizzle migrations before starting the app.
# The database itself is created by the deploy platform (dockploy DB service);
# migrate only creates/updates the tables (idempotent - safe every boot).
echo "Running drizzle migrations..."
varlock run -- drizzle-kit migrate

# Refuse startup if the checked-out migration history differs from the database.
varlock run -- node src/intranet/db/preflight.ts

# Start the Nitro server
exec varlock run -- node .output/server/index.mjs
