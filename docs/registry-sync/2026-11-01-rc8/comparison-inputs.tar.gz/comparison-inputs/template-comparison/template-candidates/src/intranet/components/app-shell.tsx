import { Link, useRouterState } from "@tanstack/react-router";
import { UserRoundIcon, UsersIcon } from "lucide-react";
import type { ReactNode } from "react";

import { Navbar } from "#/components/navigation/navbar";
import { useSignOut, type useAuth } from "#/intranet/auth/hooks";
import { isAdmin } from "#/intranet/auth/permissions";
import { ActionToastProvider } from "#/intranet/components/forge/action-toast";
import { IntranetShell } from "#/intranet/components/forge/intranet/intranet-shell";
import {
  LoadingIndicator,
  LoadingProvider,
  useLoadingActivity,
} from "#/intranet/components/forge/loading-indicator";
import type {
  IntranetLinkProps,
  IntranetNavGroup,
} from "#/intranet/components/forge/navigation/intranet-sidebar";
import { t, type Dictionary } from "#/lib/i18n";
import { type Locale } from "#/lib/i18n/config";
import { SITE_LOGO_MARK } from "#/lib/site/constants";

function SidebarLink({ href, ...props }: IntranetLinkProps) {
  return <Link to={href} {...props} />;
}

interface AppShellProps {
  siteName: string;
  locale: Locale;
  dict: Dictionary;
  user: NonNullable<ReturnType<typeof useAuth>["user"]>;
  controls?: ReactNode;
  children: ReactNode;
}

/** Host integration for the shared registry shell. Add installed modules to the groups here. */
<<<<<<< /private/tmp/forge-websites-sync-0sfg9h88/sites/soleva/current-before-template/src/intranet/components/app-shell.tsx
export function AppShell({ siteName, locale, dict, user, controls, children }: AppShellProps) {
=======
export function AppShell(props: AppShellProps) {
  return (
    <LoadingProvider>
      <ActionToastProvider closeLabel={t(props.dict, "common.close")}>
        <AppShellContent {...props} />
      </ActionToastProvider>
    </LoadingProvider>
  );
}

function AppShellContent({
  siteName,
  navbarProps,
  locale,
  dict,
  user,
  controls,
  children,
}: AppShellProps) {
>>>>>>> /private/tmp/forge-websites-sync-0sfg9h88/sites/soleva/template-incoming/src/intranet/components/app-shell.tsx
  const signOut = useSignOut();
  const loading = useRouterState({ select: (state) => state.isLoading });
  useLoadingActivity(loading);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const groups: IntranetNavGroup[] = [
    {
      id: "workspace",
      items: [
        {
          id: "profile",
          label: t(dict, "profile.title"),
          href: `/${locale}/intranet`,
          exact: true,
          icon: <UserRoundIcon />,
        },
        ...(isAdmin(user.role)
          ? [
              {
                id: "employees",
                label: t(dict, "employees.title"),
                href: `/${locale}/intranet/employees`,
                icon: <UsersIcon />,
              },
            ]
          : []),
      ],
    },
  ];

  return (
    <IntranetShell
      brand={{
        name: siteName,
        href: `/${locale}`,
        logo: <img src={SITE_LOGO_MARK} alt="" width={28} height={28} />,
      }}
      user={user}
      pathname={pathname}
      groups={user.mustChangePassword ? [] : groups}
      linkComponent={SidebarLink}
      profileHref={`/${locale}/intranet`}
      onSignOut={signOut}
      labels={{
        navigation: t(dict, "auth.sideNavigation"),
        toggle: t(dict, "auth.toggleNavigation"),
        close: t(dict, "common.close"),
        expand: t(dict, "auth.expand"),
        collapse: t(dict, "auth.collapse"),
        profile: t(dict, "profile.title"),
        userMenu: t(dict, "auth.accountMenu"),
        signOut: t(dict, "auth.signOut"),
        signingOut: t(dict, "auth.signingOut"),
        signOutError: t(dict, "auth.signOutError"),
      }}
      insetAs="div"
      wrapContent={false}
      renderTopbar={(toggle) => (
        <div className="relative flex items-center gap-2 bg-background px-2 print:hidden">
          <LoadingIndicator
            label={t(dict, "auth.loading")}
            className="absolute top-auto bottom-0"
          />
          {toggle}
          <div className="min-w-0 flex-1">
            <Navbar locale={locale} dict={dict} embedded />
          </div>
        </div>
      )}
    >
      {children}
    </IntranetShell>
  );
}
