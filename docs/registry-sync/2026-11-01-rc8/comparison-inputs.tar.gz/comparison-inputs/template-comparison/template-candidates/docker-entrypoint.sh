#!/bin/sh
set -e

export PATH="/app/node_modules/.bin:$PATH"

echo "Running drizzle migrations..."
varlock run -- drizzle-kit migrate

<<<<<<< /private/tmp/forge-websites-sync-0sfg9h88/sites/soleva/current-before-template/docker-entrypoint.sh
=======
# Refuse startup if the checked-out migration history differs from the database.
varlock run -- node src/intranet/db/preflight.ts

# Start the Nitro server
>>>>>>> /private/tmp/forge-websites-sync-0sfg9h88/sites/soleva/template-incoming/docker-entrypoint.sh
exec varlock run -- node .output/server/index.mjs
